const router = require('express').Router();
const Post = require('../models/Post');
const { auth, authorize } = require('../middleware/auth');

// Get all posts (everyone)
router.get('/', async (req, res) => {
  try {
    const posts = await Post.find().populate('author', 'username role');
    res.json(posts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Create post (regular_user, moderator, super_admin)
router.post('/', auth, authorize('regular_user', 'moderator', 'super_admin'), async (req, res) => {
  try {
    const post = new Post({ title: req.body.title, content: req.body.content, author: req.user._id });
    await post.save();
    res.status(201).json(post);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Update post (own post only, or super_admin)
router.put('/:id', auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });

    const isOwner = post.author.toString() === req.user._id.toString();
    const isSuperAdmin = req.user.role === 'super_admin';

    if (!isOwner && !isSuperAdmin) {
      return res.status(403).json({ message: 'You can only update your own posts' });
    }

    post.title = req.body.title || post.title;
    post.content = req.body.content || post.content;
    await post.save();
    res.json(post);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Delete post
router.delete('/:id', auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });

    const isOwner = post.author.toString() === req.user._id.toString();
    const isSuperAdmin = req.user.role === 'super_admin';
    const isModerator = req.user.role === 'moderator';

    if (!isOwner && !isSuperAdmin && !isModerator) {
      return res.status(403).json({ message: 'Access denied' });
    }

    await post.deleteOne();
    res.json({ message: 'Post deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
