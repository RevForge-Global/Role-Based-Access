const router = require('express').Router();
const Comment = require('../models/Comment');
const Post = require('../models/Post');
const { auth, authorize } = require('../middleware/auth');

// Get comments for a post
router.get('/post/:postId', async (req, res) => {
  try {
    const comments = await Comment.find({ post: req.params.postId }).populate('author', 'username role');
    res.json(comments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Create comment (regular_user, moderator, super_admin)
router.post('/', auth, authorize('regular_user', 'moderator', 'super_admin'), async (req, res) => {
  try {
    const comment = new Comment({ content: req.body.content, author: req.user._id, post: req.body.postId });
    await comment.save();
    res.status(201).json(comment);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete comment
router.delete('/:id', auth, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id).populate('post');
    if (!comment) return res.status(404).json({ message: 'Comment not found' });

    const isCommentOwner = comment.author.toString() === req.user._id.toString();
    const isPostOwner = comment.post.author.toString() === req.user._id.toString();
    const isSuperAdmin = req.user.role === 'super_admin';
    const isModerator = req.user.role === 'moderator';

    if (!isCommentOwner && !isPostOwner && !isSuperAdmin && !isModerator) {
      return res.status(403).json({ message: 'Access denied' });
    }

    await comment.deleteOne();
    res.json({ message: 'Comment deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
