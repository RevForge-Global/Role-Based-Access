const router = require('express').Router();
const User = require('../models/User');
const { auth, authorize } = require('../middleware/auth');

// Get all users (super_admin only)
router.get('/users', auth, authorize('super_admin'), async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update user role (super_admin only)
router.put('/users/:id/role', auth, authorize('super_admin'), async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { role: req.body.role },
      { new: true }
    ).select('-password');
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Delete user (super_admin only)
router.delete('/users/:id', auth, authorize('super_admin'), async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'User deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
