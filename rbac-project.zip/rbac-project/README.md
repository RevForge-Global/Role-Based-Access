# RBAC System — Role Based Access Control

## Tech Stack
- **Frontend:** React.js
- **Backend:** Node.js + Express
- **Database:** MongoDB

## Roles & Permissions

| Role | Permissions |
|------|-------------|
| Super Admin | Full access — delete anything, manage users |
| Moderator | Delete any post or comment, cannot manage users |
| Regular User | Create posts & comments, edit/delete own content only |
| Guest | View/read only — no posting or commenting |

## Setup Instructions

### Backend
```bash
cd backend
npm install
node server.js
```

### Frontend
```bash
cd frontend
npm install
npm start
```

### Environment Variables (backend/.env)
```
MONGO_URI=mongodb://localhost:27017/rbac_system
JWT_SECRET=your_secret_key
PORT=5000
```

## Features
- JWT Authentication
- Role-based access control
- Create, edit, delete posts
- Comment system with ownership rules
- Admin panel for user management
