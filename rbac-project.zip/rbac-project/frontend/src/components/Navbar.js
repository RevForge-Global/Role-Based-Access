import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const roleColors = {
  super_admin: '#e74c3c',
  moderator: '#e67e22',
  regular_user: '#27ae60',
  guest: '#95a5a6'
};

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav style={{ background: '#2c3e50', padding: '12px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <Link to="/dashboard" style={{ color: 'white', textDecoration: 'none', fontSize: '20px', fontWeight: 'bold' }}>
        RBAC System
      </Link>
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        {user && (
          <>
            <span style={{ color: 'white' }}>Hello, {user.username}</span>
            <span style={{
              background: roleColors[user.role] || '#999',
              color: 'white', padding: '4px 10px',
              borderRadius: '12px', fontSize: '12px', fontWeight: 'bold'
            }}>
              {user.role.replace('_', ' ').toUpperCase()}
            </span>
            {user.role === 'super_admin' && (
              <Link to="/admin" style={{ color: '#f39c12', textDecoration: 'none' }}>Admin Panel</Link>
            )}
            <button onClick={handleLogout} style={{
              background: '#e74c3c', color: 'white', border: 'none',
              padding: '6px 14px', borderRadius: '6px', cursor: 'pointer'
            }}>Logout</button>
          </>
        )}
      </div>
    </nav>
  );
}
