import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

const api = (token) => axios.create({
  baseURL: 'http://localhost:5000/api',
  headers: { Authorization: `Bearer ${token}` }
});

export default function Dashboard() {
  const { user } = useAuth();
  const token = localStorage.getItem('token');
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState({ title: '', content: '' });
  const [comments, setComments] = useState({});
  const [newComment, setNewComment] = useState({});
  const [editPost, setEditPost] = useState(null);

  const canPost = user?.role !== 'guest';
  const canDelete = (post) => user?.role === 'super_admin' || user?.role === 'moderator' || post.author?._id === user?.id;
  const canEdit = (post) => user?.role === 'super_admin' || post.author?._id === user?.id;
  const canDeleteComment = (comment, post) =>
    user?.role === 'super_admin' || user?.role === 'moderator' ||
    comment.author?._id === user?.id || post.author?._id === user?.id;

  useEffect(() => { fetchPosts(); }, []);

  const fetchPosts = async () => {
    const res = await axios.get('http://localhost:5000/api/posts');
    setPosts(res.data);
    res.data.forEach(p => fetchComments(p._id));
  };

  const fetchComments = async (postId) => {
    const res = await axios.get(`http://localhost:5000/api/comments/post/${postId}`);
    setComments(prev => ({ ...prev, [postId]: res.data }));
  };

  const createPost = async () => {
    if (!newPost.title || !newPost.content) return;
    await api(token).post('/posts', newPost);
    setNewPost({ title: '', content: '' });
    fetchPosts();
  };

  const deletePost = async (id) => {
    await api(token).delete(`/posts/${id}`);
    fetchPosts();
  };

  const updatePost = async () => {
    await api(token).put(`/posts/${editPost._id}`, editPost);
    setEditPost(null);
    fetchPosts();
  };

  const createComment = async (postId) => {
    if (!newComment[postId]) return;
    await api(token).post('/comments', { content: newComment[postId], postId });
    setNewComment(prev => ({ ...prev, [postId]: '' }));
    fetchComments(postId);
  };

  const deleteComment = async (commentId, postId) => {
    await api(token).delete(`/comments/${commentId}`);
    fetchComments(postId);
  };

  return (
    <div>
      <h2 style={{ color: '#2c3e50' }}>Dashboard</h2>

      {/* Role Info */}
      <div style={{ background: '#ecf0f1', padding: '12px', borderRadius: '8px', marginBottom: '20px' }}>
        <strong>Your Role: </strong>{user?.role?.replace('_', ' ').toUpperCase()} &nbsp;|&nbsp;
        {user?.role === 'guest' && '👁️ View only'}
        {user?.role === 'regular_user' && '✏️ Can create posts & comments, edit/delete own content'}
        {user?.role === 'moderator' && '🛡️ Can delete any post or comment'}
        {user?.role === 'super_admin' && '👑 Full access to everything'}
      </div>

      {/* Create Post */}
      {canPost && (
        <div style={{ background: '#fff', padding: '20px', borderRadius: '10px', boxShadow: '0 2px 10px rgba(0,0,0,0.08)', marginBottom: '24px' }}>
          <h3>Create New Post</h3>
          <input placeholder="Title" value={newPost.title}
            onChange={e => setNewPost({ ...newPost, title: e.target.value })}
            style={{ width: '100%', padding: '8px', marginBottom: '8px', borderRadius: '6px', border: '1px solid #ddd', boxSizing: 'border-box' }} />
          <textarea placeholder="Content" value={newPost.content}
            onChange={e => setNewPost({ ...newPost, content: e.target.value })}
            style={{ width: '100%', padding: '8px', marginBottom: '8px', borderRadius: '6px', border: '1px solid #ddd', height: '80px', boxSizing: 'border-box' }} />
          <button onClick={createPost} style={{ background: '#27ae60', color: 'white', border: 'none', padding: '8px 20px', borderRadius: '6px', cursor: 'pointer' }}>
            Post
          </button>
        </div>
      )}

      {/* Edit Post Modal */}
      {editPost && (
        <div style={{ background: '#fff3cd', padding: '20px', borderRadius: '10px', marginBottom: '20px', border: '1px solid #ffc107' }}>
          <h3>Edit Post</h3>
          <input value={editPost.title}
            onChange={e => setEditPost({ ...editPost, title: e.target.value })}
            style={{ width: '100%', padding: '8px', marginBottom: '8px', borderRadius: '6px', border: '1px solid #ddd', boxSizing: 'border-box' }} />
          <textarea value={editPost.content}
            onChange={e => setEditPost({ ...editPost, content: e.target.value })}
            style={{ width: '100%', padding: '8px', marginBottom: '8px', borderRadius: '6px', border: '1px solid #ddd', height: '80px', boxSizing: 'border-box' }} />
          <button onClick={updatePost} style={{ background: '#2c3e50', color: 'white', border: 'none', padding: '8px 20px', borderRadius: '6px', cursor: 'pointer', marginRight: '8px' }}>Update</button>
          <button onClick={() => setEditPost(null)} style={{ background: '#e74c3c', color: 'white', border: 'none', padding: '8px 20px', borderRadius: '6px', cursor: 'pointer' }}>Cancel</button>
        </div>
      )}

      {/* Posts List */}
      {posts.map(post => (
        <div key={post._id} style={{ background: '#fff', padding: '20px', borderRadius: '10px', boxShadow: '0 2px 10px rgba(0,0,0,0.08)', marginBottom: '20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <h3 style={{ margin: '0 0 6px', color: '#2c3e50' }}>{post.title}</h3>
              <small style={{ color: '#888' }}>By {post.author?.username} ({post.author?.role})</small>
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              {canEdit(post) && (
                <button onClick={() => setEditPost(post)} style={{ background: '#f39c12', color: 'white', border: 'none', padding: '4px 12px', borderRadius: '6px', cursor: 'pointer' }}>Edit</button>
              )}
              {canDelete(post) && (
                <button onClick={() => deletePost(post._id)} style={{ background: '#e74c3c', color: 'white', border: 'none', padding: '4px 12px', borderRadius: '6px', cursor: 'pointer' }}>Delete</button>
              )}
            </div>
          </div>
          <p style={{ color: '#555', marginTop: '10px' }}>{post.content}</p>

          {/* Comments */}
          <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid #eee' }}>
            <strong style={{ color: '#666' }}>Comments:</strong>
            {(comments[post._id] || []).map(comment => (
              <div key={comment._id} style={{ background: '#f8f9fa', padding: '8px 12px', borderRadius: '6px', margin: '6px 0', display: 'flex', justifyContent: 'space-between' }}>
                <span><strong>{comment.author?.username}:</strong> {comment.content}</span>
                {canDeleteComment(comment, post) && (
                  <button onClick={() => deleteComment(comment._id, post._id)} style={{ background: '#e74c3c', color: 'white', border: 'none', padding: '2px 8px', borderRadius: '4px', cursor: 'pointer', fontSize: '12px' }}>×</button>
                )}
              </div>
            ))}
            {canPost && (
              <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
                <input placeholder="Add a comment..." value={newComment[post._id] || ''}
                  onChange={e => setNewComment(prev => ({ ...prev, [post._id]: e.target.value }))}
                  style={{ flex: 1, padding: '6px', borderRadius: '6px', border: '1px solid #ddd' }} />
                <button onClick={() => createComment(post._id)} style={{ background: '#2c3e50', color: 'white', border: 'none', padding: '6px 14px', borderRadius: '6px', cursor: 'pointer' }}>
                  Comment
                </button>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
