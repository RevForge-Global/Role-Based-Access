import React, { useState, useEffect } from 'react';
import axios from 'axios';

const roleColors = {
  super_admin: '#e74c3c',
  moderator: '#e67e22',
  regular_user: '#27ae60',
  guest: '#95a5a6'
};

export default function AdminPanel() {
  const token = localStorage.getItem('token');
  const [users, setUsers] = useState([]);

  const api = axios.create({
    baseURL: 'http://localhost:5000/api',
    headers: { Authorization: `Bearer ${token}` }
  });

  useEffect(() => { fetchUsers(); }, []);

  const fetchUsers = async () => {
    const res = await api.get('/admin/users');
    setUsers(res.data);
  };

  const updateRole = async (id, role) => {
    await api.put(`/admin/users/${id}/role`, { role });
    fetchUsers();
  };

  const deleteUser = async (id) => {
    if (window.confirm('Delete this user?')) {
      await api.delete(`/admin/users/${id}`);
      fetchUsers();
    }
  };

  return (
    <div>
      <h2 style={{ color: '#e74c3c' }}>👑 Admin Panel — User Management</h2>
      <div style={{ background: '#fff', borderRadius: '10px', boxShadow: '0 2px 10px rgba(0,0,0,0.08)', overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: '#2c3e50', color: 'white' }}>
              <th style={{ padding: '12px', textAlign: 'left' }}>Username</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Email</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Role</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Change Role</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u._id} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '12px' }}>{u.username}</td>
                <td style={{ padding: '12px' }}>{u.email}</td>
                <td style={{ padding: '12px' }}>
                  <span style={{ background: roleColors[u.role], color: 'white', padding: '3px 10px', borderRadius: '10px', fontSize: '12px' }}>
                    {u.role.replace('_', ' ').toUpperCase()}
                  </span>
                </td>
                <td style={{ padding: '12px' }}>
                  <select value={u.role} onChange={e => updateRole(u._id, e.target.value)}
                    style={{ padding: '4px 8px', borderRadius: '6px', border: '1px solid #ddd' }}>
                    <option value="super_admin">Super Admin</option>
                    <option value="moderator">Moderator</option>
                    <option value="regular_user">Regular User</option>
                    <option value="guest">Guest</option>
                  </select>
                </td>
                <td style={{ padding: '12px' }}>
                  <button onClick={() => deleteUser(u._id)} style={{ background: '#e74c3c', color: 'white', border: 'none', padding: '4px 12px', borderRadius: '6px', cursor: 'pointer' }}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
